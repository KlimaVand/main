#import <UIKit/UIKit.h>

@interface InvalidInputIndicatorTableViewCell : UITableViewCell

@property (nonatomic) BOOL validInput;

@end
