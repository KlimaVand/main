#import "ReportLocationTableViewCell.h"

@implementation ReportLocationTableViewCell

@end
