#import <UIKit/UIKit.h>

@interface SaveButtonTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *saveButton;

@end
