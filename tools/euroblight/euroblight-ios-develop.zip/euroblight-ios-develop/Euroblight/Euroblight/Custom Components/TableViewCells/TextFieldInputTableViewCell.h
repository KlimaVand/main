#import <UIKit/UIKit.h>
#import "InvalidInputIndicatorTableViewCell.h"

@interface TextFieldInputTableViewCell : InvalidInputIndicatorTableViewCell

@property (weak, nonatomic) IBOutlet UITextField *textField;

@end
