#import "ReportInputTableViewCell.h"

@implementation ReportInputTableViewCell

@end
