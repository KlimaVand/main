#import <UIKit/UIKit.h>

@interface UnsentReportTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *customImageView;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;

@end
