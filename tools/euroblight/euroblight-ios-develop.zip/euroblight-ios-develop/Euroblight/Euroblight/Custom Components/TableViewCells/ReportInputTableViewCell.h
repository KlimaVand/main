#import <UIKit/UIKit.h>

@interface ReportInputTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UILabel *customTitleLabel;

@end
