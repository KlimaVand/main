#import <UIKit/UIKit.h>

@interface UIColor (Euroblight)

+ (UIColor *)applicationTintColor;
+ (UIColor *)cellInvalidInputColor;

@end
