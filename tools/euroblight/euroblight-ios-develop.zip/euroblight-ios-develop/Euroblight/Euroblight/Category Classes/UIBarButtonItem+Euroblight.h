#import <UIKit/UIKit.h>

@interface UIBarButtonItem (Euroblight)

+ (UIBarButtonItem *)createBarButtonFromImageWithName:(NSString *)imageName target:(id)target action:(SEL)action;

@end
