#import <UIKit/UIKit.h>

@interface UIImage (Euroblight)

+ (UIImage *)imageWithColor:(UIColor *)color;

@end
