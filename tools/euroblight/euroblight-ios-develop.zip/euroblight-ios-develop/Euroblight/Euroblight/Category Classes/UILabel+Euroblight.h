#import <UIKit/UIKit.h>

@interface UILabel (Euroblight)

+ (UILabel *)pickerLabel;

@end
