#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ReportTableViewController : UITableViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource,CLLocationManagerDelegate>

@end
