#import <UIKit/UIKit.h>

@interface UnsentReportsTableViewController : UITableViewController <UIAlertViewDelegate>

@end
