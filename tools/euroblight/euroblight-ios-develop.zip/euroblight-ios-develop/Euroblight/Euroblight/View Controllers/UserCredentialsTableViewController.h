#import <UIKit/UIKit.h>

@interface UserCredentialsTableViewController : UITableViewController <UITextFieldDelegate>

@end
