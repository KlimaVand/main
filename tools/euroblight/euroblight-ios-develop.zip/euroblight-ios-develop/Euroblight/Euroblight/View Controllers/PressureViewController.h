#import <UIKit/UIKit.h>

@interface PressureViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate, UIScrollViewDelegate>

@end
