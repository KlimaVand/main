#import <Foundation/Foundation.h>

@interface Constants : NSObject

extern NSInteger const TOOLBAR_HEIGHT;
extern CGFloat const OVELAY_VIEWS_ALPHA;

@end
