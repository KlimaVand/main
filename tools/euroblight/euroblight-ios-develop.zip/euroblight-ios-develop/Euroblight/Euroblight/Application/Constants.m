#import "Constants.h"

@implementation Constants

NSInteger const TOOLBAR_HEIGHT = 44;
CGFloat const OVELAY_VIEWS_ALPHA = 0.7;

@end
